package com.itheima.thread.demo05;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;

public class SemaphoreDemo {

    // 定义成员变量，定义办理业务人员的总数量
    private static int clientTotal = 10 ;

    // 可同时受理业务的窗口数量（同时并发执行的线程数）
    public static int threadTotal = 2;

    public static void main(String[] args) {

        // 创建一个线程池对象
        ExecutorService executorService = Executors.newCachedThreadPool();

        // 补全代码

        // 模拟多个人员去办理业务
        for (int i = 0; i < clientTotal; i++) {
            int count = i ;     // 将i的值重新设置给一个变量，因为在线程池中无法访问到循环变量i
            executorService.execute(() -> {
                try {

                    // 补全代码

                    resolve(count);
                    System.out.println("服务号" + count + "，业务受理完毕中");

                    // 补全代码

                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        }

        // 关闭线程池
        executorService.shutdown();

    }

    // 模拟业务受理方法
    private static void resolve(int i) throws InterruptedException {
        System.out.println("服务号" + i + "，受理业务中");
        Thread.sleep(2000);
    }

}
